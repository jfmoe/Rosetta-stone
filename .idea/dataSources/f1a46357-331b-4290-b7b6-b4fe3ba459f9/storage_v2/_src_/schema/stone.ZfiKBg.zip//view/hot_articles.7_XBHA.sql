create view hot_articles as
  select `stone`.`articles`.`article_id` AS `article_id`,
         `stone`.`articles`.`title`      AS `title`,
         `stone`.`articles`.`get_read`   AS `get_read`,
         `stone`.`articles`.`get_stars`  AS `get_stars`,
         `stone`.`users`.`nickname`      AS `nickname`,
         `stone`.`articles`.`author_id`  AS `author_id`
  from (`stone`.`articles` join `stone`.`users`)
  where ((`stone`.`articles`.`author_id` = `stone`.`users`.`user_id`) and (`stone`.`articles`.`article_is_delete` = 0));

